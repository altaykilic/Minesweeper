import pygame
import os

pygame.init()

numbers = [pygame.image.load(os.path.join('assets','number0.png')), pygame.image.load(os.path.join('assets','number1.png')), pygame.image.load(os.path.join('assets','number2.png')), pygame.image.load(os.path.join('assets','number3.png')), pygame.image.load(os.path.join('assets','number4.png')), pygame.image.load(os.path.join('assets','number5.png')), pygame.image.load(os.path.join('assets','number6.png')), pygame.image.load(os.path.join('assets','number7.png')), pygame.image.load(os.path.join('assets','number8.png')), pygame.image.load(os.path.join('assets','number9.png'))]

facebg = pygame.image.load('assets/facebg0.png')
face0 = pygame.image.load('assets/face0.png')
face1 = pygame.image.load('assets/face1.png')

screen = pygame.display.set_mode((500,100))
screen.fill((230,230,230))
# screen.blit(facebg, (20,20))
# screen.blit(face0, (20,20))
# pygame.display.flip()

timerval = 0
customevent = pygame.USEREVENT + 1
pygame.time.set_timer(customevent, 1000)

def blitnumber(n: int, x: int, y: int, length: int = 0) -> None:
	digits = []
	while n > 0:
		digits.append(n%10)
		n //= 10
	
	pos = (x,y)
	while length - len(digits) > 0:
		screen.blit(numbers[0], pos)
		pos = (pos[0]+17, pos[1])
		length -= 1
	
	for i in digits[::-1]:
		screen.blit(numbers[i], pos)
		pos = (pos[0]+17, pos[1])

# blitnumber(15, 70, 20, 10)

run = 1
while run:
	pygame.display.set_caption(str(timerval))
	
	screen.blit(facebg, (20,20))
	blitnumber(timerval, 70, 20, 3)
	if pygame.mouse.get_pressed(3)[0]:
		screen.blit(face1, (20,20))
	else:
		screen.blit(face0, (20,20))
	pygame.display.flip()
	
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run = 0
			break
		
		elif event.type == customevent:
			timerval += 1
