mayın tarlası oynamak için minesweeper.py dosyasını python ile çalıştırmanız yeterlidir.


invalid input hatası yememek için yapmanız gerekenler:
-bütün girdilere 4'ten büyük tamsayılar vermek
-"mines"ı width*height-9'dan küçük/eşit vermek


eğer mine_explosion.mp3 dosyasıyla ilgili bir hata alırsanız
minesweeper.py dosyasındaki 37 ve 111. satırların başına # koyunuz


assets klasöründeki çizimler bana ait (graphik designır)

oynarken sesin kısık olduğundan emin olunuz.

Altay Kılıç, 23.04.2021